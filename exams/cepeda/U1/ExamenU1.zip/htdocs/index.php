<?php
require_once 'conexion.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tree Company</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>TREES COMPANY</h1>
    <hr size="3">
    <h2>Registered Trees</h2>

<?php
try {
    $db = new conexion();
    $pdo = $db->connect();

    $stmt = $pdo->query("SELECT treeName, treePrice, stock, treeColor FROM trees");
    $trees = $stmt->fetchAll();

    if (count($trees) > 0): ?>
        <table border="1" cellpadding="9" cellspacing="0">
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Color</th>
            </tr>
            <?php foreach ($trees as $tree): ?>
            <tr>
                <td><?= htmlspecialchars($tree['treeName']) ?></td>
                <td><?= htmlspecialchars($tree['treePrice']) ?></td>
                <td><?= htmlspecialchars($tree['stock']) ?></td>
                <td><?= htmlspecialchars($tree['treeColor']) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Still no trees...</p>
    <?php endif;
} catch (Exception $e) {
    echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>

    <hr size="3">
    <p>This is the web page to read all trees.</p>
    <p>Please get us contact. Remember to <strong>read all</strong> the information at the end of your process.</p>
    <script src="js/trees.js"></script>
</body>
</html>
