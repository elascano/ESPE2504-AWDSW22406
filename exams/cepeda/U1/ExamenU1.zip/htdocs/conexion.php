<?php
class conexion {
    private $host = 'sql205.infinityfree.com';
    private $dbname = 'if0_39084053_Trees';
    private $username = 'if0_39084053';
    private $password = 'sCAYYiVtOXIqil';

    public function connect() {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8mb4";
            $pdo = new PDO($dsn, $this->username, $this->password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $pdo;
        } catch (PDOException $e) {
            // Lanza la excepción para que la maneje el código que usa esta conexión
            throw new Exception("Error en la conexión: " . $e->getMessage());
        }
    }
}
?>
