document.addEventListener("DOMContentLoaded", function () {
    let prices = document.querySelectorAll(".tree-price");
    let total = 0;

    prices.forEach(cell => {
        let value = parseFloat(cell.textContent);
        if (!isNaN(value)) {
            total += value;
        }
    });

    document.getElementById("totalPrice").textContent = total.toFixed(2);
});

