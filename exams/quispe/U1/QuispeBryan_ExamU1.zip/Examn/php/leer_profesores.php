<?php
$conn = new mysqli("HOST", "USER", "PASS", "DB");
if ($conn->connect_error) die("Error: " . $conn->connect_error);

$sql = "SELECT * FROM profesores";
$result = $conn->query($sql);

echo "<table border='1'>";
echo "<tr><th>ID</th><th>Nombre</th><th>Departamento</th><th>Experiencia</th><th>Salario</th><th>Publicaciones</th><th>Salario Total</th></tr>";
while ($row = $result->fetch_assoc()) {
    $salario_total = $row["salario_base"] + ($row["nro_publicaciones"] * 100) + ($row["años_experiencia"] * 50);
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['nombre']} {$row['apellido']}</td>
        <td>{$row['departamento']}</td>
        <td>{$row['años_experiencia']}</td>
        <td>{$row['salario_base']}</td>
        <td>{$row['nro_publicaciones']}</td>
        <td>$salario_total</td>
    </tr>";
}
echo "</table>";
$conn->close();
?>
