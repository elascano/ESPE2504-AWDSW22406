<?php
$conn = new mysqli("HOST", "USER", "PASS", "DB");
if ($conn->connect_error) die("Error: " . $conn->connect_error);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $departamento = $_POST['departamento'];
    $experiencia = $_POST['años_experiencia'];
    $salario = $_POST['salario_base'];
    $publicaciones = $_POST['nro_publicaciones'];

    $sql = "INSERT INTO profesores (nombre, apellido, departamento, años_experiencia, salario_base, nro_publicaciones)
            VALUES ('$nombre', '$apellido', '$departamento', $experiencia, $salario, $publicaciones)";
    
    if ($conn->query($sql)) echo "Profesor insertado correctamente.";
    else echo "Error: " . $conn->error;
}
$conn->close();
?>
